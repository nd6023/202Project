import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WorldStatergy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface WorldResetStrategy
{
    public  void reset();
     
}
